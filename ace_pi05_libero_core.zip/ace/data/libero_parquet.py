from __future__ import annotations

from io import BytesIO
from pathlib import Path
from typing import Any

import torch


def _resolve_lerobot_dataset_root(dataset_root: str | Path) -> Path:
    root = Path(dataset_root)
    if (root / "meta" / "tasks.parquet").exists():
        return root
    if (root / "libero" / "meta" / "tasks.parquet").exists():
        return root / "libero"
    if (root / "libero_plus" / "meta" / "tasks.parquet").exists():
        return root / "libero_plus"
    return root


def load_libero_tasks(dataset_root: str | Path) -> dict[int, str]:
    import pandas as pd

    resolved = _resolve_lerobot_dataset_root(dataset_root)
    tasks = pd.read_parquet(resolved / "meta" / "tasks.parquet")
    return {int(row.task_index): str(index) for index, row in tasks.iterrows()}


def decode_png_tensor(value: dict[str, bytes]) -> torch.Tensor:
    import numpy as np
    from PIL import Image

    image = Image.open(BytesIO(value["bytes"])).convert("RGB")
    array = np.asarray(image).copy()
    return torch.from_numpy(array).permute(2, 0, 1).contiguous().float() / 255.0


class LiberoDemoReader:
    """Direct LIBERO parquet reader for confidence post-training.

    Vanilla LIBERO stores PNG bytes in the parquet rows. LIBERO-plus stores
    observations as video features, so this reader falls back to LeRobotDataset
    video decoding and maps its ``front``/``wrist`` cameras to the PI0.5 LIBERO
    camera names expected by the local policy preprocessor.
    """

    def __init__(self, dataset_root: str | Path, *, video_backend: str = "pyav") -> None:
        import pandas as pd
        import pyarrow.parquet as pq

        self.dataset_root = _resolve_lerobot_dataset_root(dataset_root)
        self.data_dir = self.dataset_root / "data" / "chunk-000"
        self.tasks = load_libero_tasks(self.dataset_root)
        self.video_backend = video_backend
        self._files: dict[int, Any] = {}
        self._ranges: list[tuple[int, int, int]] = []
        start = 0
        self._data_columns: set[str] = set()
        for path in sorted(self.data_dir.glob("file-*.parquet")):
            parquet_file = pq.ParquetFile(path)
            file_index = int(path.stem.split("-")[-1])
            rows = int(parquet_file.metadata.num_rows)
            self._ranges.append((start, start + rows, file_index))
            start += rows
            if not self._data_columns:
                self._data_columns = set(parquet_file.schema_arrow.names)

        episodes_path = self.dataset_root / "meta" / "episodes" / "chunk-000" / "file-000.parquet"
        self.episodes = pd.read_parquet(episodes_path)
        self._video_dataset = None
        self._image_column_map = self._infer_image_column_map()
        if not self._image_column_map:
            self._video_dataset = self._make_video_dataset()
            self._image_column_map = self._infer_video_image_map()

    def _infer_image_column_map(self) -> dict[str, str]:
        if {"observation.images.image", "observation.images.image2"}.issubset(self._data_columns):
            return {
                "observation.images.image": "observation.images.image",
                "observation.images.image2": "observation.images.image2",
            }
        if {"observation.images.front", "observation.images.wrist"}.issubset(self._data_columns):
            return {
                "observation.images.front": "observation.images.image",
                "observation.images.wrist": "observation.images.image2",
            }
        return {}

    def _make_video_dataset(self):
        from lerobot.datasets.lerobot_dataset import LeRobotDataset

        repo_id = "lerobot/libero_plus" if self.dataset_root.name == "libero_plus" else "lerobot/libero"
        return LeRobotDataset(
            repo_id=repo_id,
            root=self.dataset_root,
            download_videos=False,
            video_backend=self.video_backend,
        )

    def _infer_video_image_map(self) -> dict[str, str]:
        if self._video_dataset is None:
            return {}
        features = set(self._video_dataset.features)
        if {"observation.images.image", "observation.images.image2"}.issubset(features):
            return {
                "observation.images.image": "observation.images.image",
                "observation.images.image2": "observation.images.image2",
            }
        if {"observation.images.front", "observation.images.wrist"}.issubset(features):
            return {
                "observation.images.front": "observation.images.image",
                "observation.images.wrist": "observation.images.image2",
            }
        raise KeyError(f"Unsupported image features for {self.dataset_root}: {sorted(features)}")

    def file_index_for_global_index(self, global_index: int) -> int:
        for start, end, file_index in self._ranges:
            if start <= global_index < end:
                return file_index
        raise IndexError(f"global_index={global_index} is outside dataset ranges.")

    def _file(self, file_index: int):
        import pandas as pd

        if file_index not in self._files:
            self._files[file_index] = pd.read_parquet(self.data_dir / f"file-{file_index:03d}.parquet")
        return self._files[file_index]

    def read_row(self, global_index: int) -> dict[str, Any]:
        file_index = self.file_index_for_global_index(global_index)
        df = self._file(file_index)
        row = df[df["index"] == global_index]
        if row.empty:
            raise RuntimeError(f"No row for global_index={global_index} in file-{file_index:03d}.")
        return row.iloc[0].to_dict()

    def read_action_window(self, global_index: int, episode_to_index: int, horizon: int) -> torch.Tensor:
        rows = []
        end_index = min(global_index + horizon, episode_to_index)
        current = global_index
        while len(rows) < horizon and current < end_index:
            file_index = self.file_index_for_global_index(current)
            df = self._file(file_index)
            part = df[(df["index"] >= current) & (df["index"] < end_index)]
            records = part.to_dict("records")
            if not records:
                raise RuntimeError(f"No action rows at global_index={current}.")
            rows.extend(records)
            current = int(records[-1]["index"]) + 1
        actions = torch.stack([torch.as_tensor(r["action"].copy(), dtype=torch.float32) for r in rows], dim=0)
        if actions.shape[0] < horizon:
            actions = torch.cat([actions, actions[-1:].expand(horizon - actions.shape[0], -1)], dim=0)
        return actions[:horizon]

    def _read_images(self, row: dict[str, Any], global_index: int) -> dict[str, torch.Tensor]:
        images: dict[str, torch.Tensor] = {}
        if self._video_dataset is None:
            for src, dst in self._image_column_map.items():
                images[dst] = decode_png_tensor(row[src])
            return images

        item = self._video_dataset[global_index]
        for src, dst in self._image_column_map.items():
            images[dst] = item[src].float()
        return images

    def read_observation(self, global_index: int) -> dict[str, Any]:
        row = self.read_row(global_index)
        task_index = int(row["task_index"])
        obs = {
            **self._read_images(row, global_index),
            "observation.state": torch.as_tensor(row["observation.state"].copy(), dtype=torch.float32),
            "task": self.tasks[task_index],
            "task_index": task_index,
            "episode_index": int(row["episode_index"]),
            "index": int(row["index"]),
        }
        return obs

    def sample_pair_indices(self, *, rng, horizon: int, execute_steps: int, batch_size: int) -> list[tuple[int, int, int]]:
        pairs = []
        valid = self.episodes[self.episodes["length"] >= horizon + execute_steps]
        for _ in range(batch_size):
            ep = valid.iloc[int(rng.integers(0, len(valid)))]
            start = int(ep["dataset_from_index"])
            stop = int(ep["dataset_to_index"]) - horizon - execute_steps
            old_index = int(rng.integers(start, stop + 1))
            pairs.append((old_index, old_index + execute_steps, int(ep["dataset_to_index"])))
        return pairs
